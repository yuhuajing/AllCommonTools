defmodule BlockScoutWeb.Tokens.Instance.HolderView do
  use BlockScoutWeb, :view

  alias BlockScoutWeb.Tokens.Instance.OverviewView
end
