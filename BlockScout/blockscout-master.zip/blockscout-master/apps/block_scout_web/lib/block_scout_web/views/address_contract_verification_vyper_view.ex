defmodule BlockScoutWeb.AddressContractVerificationVyperView do
  use BlockScoutWeb, :view

  alias Explorer.Chain
  alias Explorer.Chain.SmartContract
end
