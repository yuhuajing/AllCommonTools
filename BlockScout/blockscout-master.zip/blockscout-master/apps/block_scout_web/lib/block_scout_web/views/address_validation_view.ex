defmodule BlockScoutWeb.AddressValidationView do
  use BlockScoutWeb, :view

  # import BlockScoutWeb.AddressView, only: [contract?: 1, smart_contract_verified?: 1]
end
