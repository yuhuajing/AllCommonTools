defmodule BlockScoutWeb.AddressReadContractView do
  use BlockScoutWeb, :view
end
