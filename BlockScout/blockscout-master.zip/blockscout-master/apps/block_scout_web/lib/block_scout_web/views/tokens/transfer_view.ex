defmodule BlockScoutWeb.Tokens.TransferView do
  use BlockScoutWeb, :view

  alias BlockScoutWeb.Tokens.OverviewView
  alias Explorer.Chain
  alias Explorer.Chain.Address
end
