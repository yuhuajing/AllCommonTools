defmodule BlockScoutWeb.AddressContractVerificationCommonFieldsView do
  use BlockScoutWeb, :view
end
